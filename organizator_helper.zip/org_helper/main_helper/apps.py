from django.apps import AppConfig


class MainNelperConfig(AppConfig):
    name = 'main_helper'
