from django.apps import AppConfig


class ClientsBaseConfig(AppConfig):
    name = 'clients_base'
