from django.apps import AppConfig


class OrgHelperApiConfig(AppConfig):
    name = 'org_helper_api'
