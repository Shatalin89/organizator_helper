from django.apps import AppConfig


class EventsBaseConfig(AppConfig):
    name = 'events_base'
